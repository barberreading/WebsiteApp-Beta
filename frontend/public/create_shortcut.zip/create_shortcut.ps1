$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\Staff Management.lnk")
$Shortcut.TargetPath = "$PSScriptRoot\start_staff_management.bat"
$Shortcut.WorkingDirectory = "$PSScriptRoot"
$Shortcut.Description = "Launch Staff Management Application"
$Shortcut.IconLocation = "$PSScriptRoot\head_icon.ico"
$Shortcut.Save()

Write-Host "Desktop shortcut created successfully!" -ForegroundColor Green
Write-Host "You can now launch the Staff Management application from your desktop." -ForegroundColor Green